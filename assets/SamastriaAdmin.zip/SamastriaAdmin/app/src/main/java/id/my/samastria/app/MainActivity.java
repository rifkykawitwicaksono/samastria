
package id.my.samastria.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
import android.webkit.CookieManager;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout container;
    private View splashView;
    private final Handler handler = new Handler();
    private boolean pageStarted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        container = new FrameLayout(this);
        container.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        progressBar = new ProgressBar(
            this, null, android.R.attr.progressBarStyleHorizontal
        );
        FrameLayout.LayoutParams progressParams =
            new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 8,
                Gravity.TOP
            );
        progressBar.setLayoutParams(progressParams);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);

        TextView logo = new TextView(this);
        logo.setText("SAMASTRIA");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(30);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);

        TextView tagline = new TextView(this);
        tagline.setText("Belanja mudah, nyaman, dan terpercaya");
        tagline.setTextColor(Color.WHITE);
        tagline.setTextSize(14);
        tagline.setGravity(Gravity.CENTER);

        FrameLayout splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.rgb(20, 115, 75));

        FrameLayout splashContent = new FrameLayout(this);
        TextView splashText = new TextView(this);
        splashText.setText("SAMASTRIA\n\nBelanja mudah, nyaman, dan terpercaya");
        splashText.setTextColor(Color.WHITE);
        splashText.setTextSize(22);
        splashText.setGravity(Gravity.CENTER);
        splashText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        splashContent.addView(splashText, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        splash.addView(splashContent, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        splashView = splash;

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setSupportMultipleWindows(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(
                WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();

                if ("http".equalsIgnoreCase(scheme)
                    || "https".equalsIgnoreCase(scheme)) {
                    return false;
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress >= 100) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
        });

        CookieManager.getInstance().setAcceptCookie(true);

        container.addView(webView);
        container.addView(progressBar);
        container.addView(splashView);
        setContentView(container);

        if (savedInstanceState == null) {
            handler.postDelayed(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (splashView != null) {
                    container.removeView(splashView);
                    splashView = null;
                }
                webView.loadUrl("https://samastria.my.id/");
            }, 1500);
        } else {
            container.removeView(splashView);
            splashView = null;
            webView.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
    private void handleBackAction() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            new android.app.AlertDialog.Builder(this)
                .setTitle("Keluar dari Samastria?")
                .setMessage("Apakah Anda yakin ingin keluar dari aplikasi?")
                .setNegativeButton("Batal", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Keluar", (dialog, which) -> finish())
                .show();
        }
    }

    @Override
    public void onBackPressed() {
        handleBackAction();
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        if (event.getKeyCode() == android.view.KeyEvent.KEYCODE_BACK && event.getAction() == android.view.KeyEvent.ACTION_UP) {
            handleBackAction();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
